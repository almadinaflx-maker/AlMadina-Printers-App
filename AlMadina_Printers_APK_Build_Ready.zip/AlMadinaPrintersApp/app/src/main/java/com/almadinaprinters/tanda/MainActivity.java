package com.almadinaprinters.tanda;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new AndroidBridge(this), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    public class AndroidBridge {
        Activity a;
        AndroidBridge(Activity x){a=x;}
        @JavascriptInterface public void requestLocation(){
            if (android.os.Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION}, 44);
                return;
            }
            try {
                LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
                Location loc=null;
                for(String p: lm.getProviders(true)){
                    Location q=lm.getLastKnownLocation(p);
                    if(q!=null && (loc==null || q.getTime()>loc.getTime())) loc=q;
                }
                if(loc!=null) {
                    String s=loc.getLatitude()+","+loc.getLongitude();
                    web.evaluateJavascript("window.setLocationFromAndroid("+JSONObjectQuote(s)+")", null);
                } else {
                    web.evaluateJavascript("window.locationUnavailable()", null);
                }
            } catch(Exception e){ web.evaluateJavascript("window.locationUnavailable()", null); }
        }
        @JavascriptInterface public void openMaps(String q){
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="+Uri.encode(q)))); } catch(Exception ignored){}
        }
        private String JSONObjectQuote(String s){ return "'" + s.replace("\\","\\\\").replace("'","\\'") + "'"; }
    }
}
